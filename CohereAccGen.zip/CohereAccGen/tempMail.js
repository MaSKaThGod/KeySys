const puppeteer = require("puppeteer");

async function getTempMail() {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();
  await page.goto("https://tempmail.ninja/");

  await page.waitForSelector('input[aria-label="Temp mail"]');
  const emailElement = await page.$('input[aria-label="Temp mail"]');
  const email = await page.evaluate((el) => el.value, emailElement);
  console.log("Temporary Email:", email);

  return { email, page, browser };
}

async function createAccountAndSendMagicLink(email) {
  try {
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();
    await page.goto("https://dashboard.cohere.com/welcome/register");

    await page.waitForSelector("#email");
    await page.type("#email", email);

    const password = email.slice(0, -1);
    await page.waitForSelector("#password");
    await page.type("#password", password);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    await page.waitForSelector("[data-element='CellButton']");

    let clickButton = async () => {
      await page.click("[data-element='CellButton']");
    };
    let loopClick = async (resolve) => {
      const stopElement = await page.$(
        ".text-p.font-body.mt-4.text-danger-500.first-letter\\:uppercase"
      );

      const verifyEmailElement = await page.$eval("h1", (el) =>
        el.innerText.includes("Verify your email")
      );

      if (stopElement || verifyEmailElement) {
        console.log(
          "Stop element or Verify your email element found, ending loop."
        );
        resolve();
        return;
      }

      await clickButton();
      setTimeout(() => loopClick(resolve), 1000);
    };

    await page.waitForSelector('button[aria-label="Accept All"]', {
      visible: true,
    });
    await page.click('button[aria-label="Accept All"]');
    await new Promise(loopClick);
    browser.close()
    return email;
  } catch (error) {
    console.error("Error creating account or sending magic link:", error);
  }
}

async function interceptAndExtractLink(page) {
  return new Promise(async (resolve, reject) => {
    let attempts = 0;
    while (attempts < 6) {
      const messages = await page.$$(
        "#inbox .msjrecibido.inbound.list-group-item"
      );

      for (let i = 0; i < messages.length; i++) {
        const id = await messages[i].evaluate((el) => el.id);
        if (id.startsWith("msg-")) {
          const idWithoutPrefix = id.slice(4);
          console.log(`Found message with ID: ${id}`);
          const button = await page.$(
            `button[data-message_id="${idWithoutPrefix}"]`
          );
          if (button) {
            await button.click();

            // Wait for the message-iframe div to appear
            try {
              await page.waitForSelector("#message-iframe iframe", {
                timeout: 10000,
              });
              const frameHandle = await page.$("#message-iframe iframe");
              const frame = await frameHandle.contentFrame();
              const iframeContent = await frame.evaluate(
                () => document.body.innerHTML
              );

              resolve(iframeContent);

              return;
            } catch (error) {
              console.log("Timeout waiting for message-iframe to appear.");
            }
          } else {
            console.log(
              `No button found with data-message_id="${idWithoutPrefix}"`
            );
          }
        }
      }

      console.log('No messages found with an ID starting with "msg-"');
      console.log("No message found, retrying in 4 seconds...");
      await new Promise((resolve) => setTimeout(resolve, 4000));
      attempts++;
    }
    console.log("No message found after 6 attempts");
    reject(new Error("No message found"));
  });
}

async function GetCompleteMail() {
  const { email, page, browser } = await getTempMail();
  await createAccountAndSendMagicLink(email);
  const verificationLink = await interceptAndExtractLink(page);

  await browser.close();
  return verificationLink;
}

module.exports = { GetCompleteMail };
