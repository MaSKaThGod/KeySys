const puppeteer = require("puppeteer");
const { GetCompleteMail } = require("./tempMail");
const fs = require('fs');

function extractConfirmationUrl(htmlString) {
  const urlPattern =
    /https:\/\/dashboard\.cohere\.com\/confirm-email\?token=[A-Za-z0-9]+/;

  const match = htmlString.match(urlPattern);

  return match ? match[0] : null;
}

async function checkForVerificationLink() {
  const mailContent = await GetCompleteMail();
  return extractConfirmationUrl(mailContent);
}

function generateRandomString(length = 6) {
  const characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

async function main() {
  const link = await checkForVerificationLink();
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();
  await page.goto(link);

  await page.waitForSelector('button[aria-label="Accept All"]', {
    visible: true,
  });
  await page.click('button[aria-label="Accept All"]');

  // Fill in the form
  const firstName = generateRandomString();
  const lastName = generateRandomString();
  await page.type("#name", firstName);
  await page.type("#lastName", lastName);

  // Submit the form
  await page.click('button[type="submit"]');

  // Handle "Skip this step" button
  await page.waitForSelector(".text-p.font-body.text-green-700", {
    visible: true,
    timeout: 5000,
  });
  const skipButton = await page.$(".text-p.font-body.text-green-700");
  await skipButton.click();

  await page.waitForSelector(".text-p.font-body.text-green-700", {
    visible: true,
    timeout: 5000,
  });
  const skipButton1 = await page.$(".text-p.font-body.text-green-700");
  await skipButton1.click();

  await page.waitForSelector('[data-component="DashboardSection"]', { timeout: 10000 });

  await page.goto("https://dashboard.cohere.com/api-keys");

  await page.waitForSelector(".hover\\:text-green-700", { timeout: 10000 });
  await page.click(".hover\\:text-green-700");

  await page.waitForSelector(
    ".bg-marble-100.rounded-lg.border-marble-500.border.w-full.px-3.focus-visible\\:outline.focus-visible\\:outline-1.focus-visible\\:outline-offset-4.focus-visible\\:outline-volcanic-900.text-p.font-body.py-4",
    { visible: true, timeout: 10000 }
  );

  const apiKey = await page.evaluate(() => {
    return document.querySelector(
      ".bg-marble-100.rounded-lg.border-marble-500.border.w-full.px-3.focus-visible\\:outline.focus-visible\\:outline-1.focus-visible\\:outline-offset-4.focus-visible\\:outline-volcanic-900.text-p.font-body.py-4"
    ).value;
  });


  console.log("API Key:", apiKey);

  fs.appendFile('keys.txt', `${apiKey}\n`, function (err) {
    if (err) throw err;
    console.log('API Key saved to keys.txt');
    browser.close().then(main); // Close browser and start main again
  });

}

main();

process.on('uncaughtException', function (err) {
    console.error(err);
    console.log("Node NOT Exiting...");
   // main()
  });
  